package com.controlStock.controlStock.controller;

import com.controlStock.controlStock.model.*;
import com.controlStock.controlStock.repository.ProductoJpaRepository;
import com.controlStock.controlStock.repository.TipoVolumenJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/producto")
public class productoController {

    @Autowired
    private ProductoJpaRepository productoJpaRepository;
    @Autowired
    private TipoVolumenJpaRepository tipoVolumenJpaRepository;

    @GetMapping(value = "/listar")
    public String listar_Productos(Model model, HttpSession session){
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }
        Usuario usuario = (Usuario) session.getAttribute("sesionUsuario");
        if(usuario.getRango()==1) {
            model.addAttribute("productos", productoJpaRepository.findAll());
        }else{
            model.addAttribute("productos", productoJpaRepository.findAllByIdUsuario(usuario.getId()));
        }
//        Usuario usuario=(Usuario) session.getAttribute("sesionUsuario");
        return "Lista";
//        return productoJpaRepository.findAll();

    }
    @GetMapping (value = "/listar/{id}")
    public Producto listar_producto(@PathVariable final int id){
        return productoJpaRepository.findById(id);
    }
    @GetMapping (value = "/nuevo")
    public String nuevo_producto(HttpSession session, Model model){
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }
        model.addAttribute("tipoVolumen", tipoVolumenJpaRepository.findAll());
        return "creareditarproducto";
    }
    @PostMapping (value = "/nuevo")
    public String crear_Producto(@ModelAttribute ProductoParams producto, HttpSession session) {
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }
        Usuario usuario = (Usuario) session.getAttribute("sesionUsuario");
        Producto producto1 = new Producto();


        producto1.setMarca(producto.getMarca());
        producto1.setCepa(producto.getCepa());
        producto1.setReserva(producto.getReserva());
        producto1.setTipo(producto.getTipo());
        producto1.setStock_maximo(producto.getStockMaximo());
        producto1.setStock_minimo(producto.getStockMinimo());
        producto1.setIdUsuario(usuario.getId());
        producto1.setStock(producto.getStock());
        TipoVolumen tp = tipoVolumenJpaRepository.findById(producto.getTipovolumen());

        producto1.setIdTipovolumen(tp);

        productoJpaRepository.save(producto1);
        return "redirect:/producto/listar";
    }
    @DeleteMapping (value = "/eliminar/{id}")
    public void eliminar_Producto(@PathVariable final int id, HttpServletResponse response){
        productoJpaRepository.delete(id);
    }
    @GetMapping (value = "/editar/{id}")
    public String editar_Producto(Model model, HttpSession session, @PathVariable final int id){
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }
            Producto producto = productoJpaRepository.findById(id);
            model.addAttribute("producto", producto) ;
            model.addAttribute("tipoVolumen", tipoVolumenJpaRepository.findAll());
            model.addAttribute("idTipoVolumen", producto.obtieneTipoVolumen());
        return "vista_editarProducto";
    }
    @PostMapping (value = "/editar/{id}")
    public String guardaProducto(@ModelAttribute ProductoParams producto,@PathVariable final int id, HttpSession session) {
        if (session.getAttribute("sesionUsuario") == null) {
            return "redirect:/usuario/login";
        }
        Producto producto1 = productoJpaRepository.findById(id);


        producto1.setMarca(producto.getMarca());
        producto1.setCepa(producto.getCepa());
        producto1.setReserva(producto.getReserva());
        producto1.setTipo(producto.getTipo());
        producto1.setStock_maximo(producto.getStockMaximo());
        producto1.setStock_minimo(producto.getStockMinimo());
        producto1.setStock(producto.getStock());

        TipoVolumen tp = tipoVolumenJpaRepository.findById(producto.getTipovolumen());

        producto1.setIdTipovolumen(tp);

        productoJpaRepository.save(producto1);
        return "redirect:/producto/listar";


    }
}
