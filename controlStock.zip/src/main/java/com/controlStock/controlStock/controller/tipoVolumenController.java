package com.controlStock.controlStock.controller;

import com.controlStock.controlStock.model.TipoVolumen;
import com.controlStock.controlStock.model.TipoVolumenParams;
import com.controlStock.controlStock.model.Usuario;
import com.controlStock.controlStock.repository.TipoVolumenJpaRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@Controller
@RequestMapping("/tipoVolumen")
public class tipoVolumenController {

    @Autowired
    private TipoVolumenJpaRepository tipoVolumenJpaRepository;

    @GetMapping(value = "/listar")
    public String mostrarLista(Model model, HttpSession session){
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }else{
            Usuario usuario = (Usuario) session.getAttribute("sesionUsuario");
            if(usuario.getRango() == 0){
                return "redirect:/producto/listar";
            }
        }

        model.addAttribute("tipoVolumen", tipoVolumenJpaRepository.findAll());
        return "tipoVolumen_lista";

    }
    @GetMapping (value = "/nuevo")
    public String nuevo_Formato(HttpSession session, Model model){
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }else{
            Usuario usuario = (Usuario) session.getAttribute("sesionUsuario");
            if(usuario.getRango() == 0){
                return "redirect:/producto/listar";
            }
        }
        return "crearformato";
    }
    @PostMapping (value = "/nuevo")
    public String crear_Formato(@ModelAttribute TipoVolumenParams tipoVolumen, HttpSession session) {
        if(session.getAttribute("sesionUsuario")==null){
            return "redirect:/usuario/login";
        }
        TipoVolumen tipoVolumen1 = new TipoVolumen();
        tipoVolumen1.setFormato(tipoVolumen.getFormato());
        tipoVolumen1.setCantidadxlitro(tipoVolumen.getCantidadxlitro());
        tipoVolumenJpaRepository.save(tipoVolumen1);

        return "redirect:/tipoVolumen/listar";
    }
    @DeleteMapping(value = "/eliminar/{id}")
    public void eliminar_Formato(@PathVariable final int id, HttpServletResponse response){
        tipoVolumenJpaRepository.delete(id);
    }
}
