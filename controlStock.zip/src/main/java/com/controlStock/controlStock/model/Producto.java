package com.controlStock.controlStock.model;

import javax.persistence.Id;

import javax.persistence.*;

@Entity
@Table(name = "Producto")
public class Producto {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id")
    private Integer id;
    @Column(name = "marca")
    private String marca;
    @Column(name = "tipo")
    private String tipo;
    @Column(name = "cepa")
    private String cepa;
    @Column(name = "reserva")
    private int reserva;
    @Column(name = "stock_minimo")
    private int stock_minimo;
    @Column(name = "stock_maximo")
    private int stock_maximo;
    @Column(name = "stock")
    private int stock;
    @Column(name = "id_usuario")
    private int idUsuario;

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }

    @OneToOne ()
    @JoinColumn (name ="id_tipovolumen")
    private TipoVolumen tipovolumen;

    public TipoVolumen getIdTipovolumen() {
        return tipovolumen;
    }

    public void setIdTipovolumen(TipoVolumen idTipovolumen) {
        this.tipovolumen = idTipovolumen;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getCepa() {
        return cepa;
    }

    public void setCepa(String cepa) {
        this.cepa = cepa;
    }

    public int getReserva() {
        return reserva;
    }

    public void setReserva(int reserva) {
        this.reserva = reserva;
    }

    public int getStock_minimo() {
        return stock_minimo;
    }

    public void setStock_minimo(int stock_minimo) {
        this.stock_minimo = stock_minimo;
    }

    public int getStock_maximo() {
        return stock_maximo;
    }

    public void setStock_maximo(int stock_maximo) {
        this.stock_maximo = stock_maximo;
    }

    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    public String getFormato(){
        return this.tipovolumen.getFormato();
    }
    public int obtieneTipoVolumen(){
        return this.tipovolumen.getId();
    }
}
