package com.controlStock.controlStock.model;

public class TipoVolumenParams {
    private String formato;
    private int cantidadxlitro;

    public String getFormato() {
        return formato;
    }

    public void setFormato(String formato) {
        this.formato = formato;
    }

    public int getCantidadxlitro() {
        return cantidadxlitro;
    }

    public void setCantidadxlitro(int cantidadxlitro) {
        this.cantidadxlitro = cantidadxlitro;
    }
}
