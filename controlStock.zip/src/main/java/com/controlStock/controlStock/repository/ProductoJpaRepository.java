package com.controlStock.controlStock.repository;

import com.controlStock.controlStock.model.Producto;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public interface ProductoJpaRepository extends JpaRepository<Producto,Integer> {

    Producto findById(int id);


    List<Producto> findAllByIdUsuario(int id);
}
