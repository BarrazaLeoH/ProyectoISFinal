package com.controlStock.controlStock.repository;

import com.controlStock.controlStock.model.TipoVolumen;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TipoVolumenJpaRepository extends JpaRepository<TipoVolumen,Integer> {
    TipoVolumen findById(int tipovolumen);
}
